from django.contrib import admin
from .models import Aprendiz
# Register your models here.
admin.site.register(Aprendiz)